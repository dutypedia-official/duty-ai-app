import {
  Platform,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";

import {
  SafeAreaView,
  View as ThemedView,
  useThemeColor,
} from "../../components/Themed";
import { Button, Card, Text } from "react-native-paper";
import { useRef, useState } from "react";
import { discoverData, pastelColors } from "@/lib/dataStore";
import * as Haptics from "expo-haptics";

interface Props {
  onCategoryChanged: (category: string) => void;
}
export default function DiscoverScreen() {
  const [activeIndex, setActiveIndex] = useState(0);
  const scrollRef = useRef<ScrollView>(null);
  const itemsRef = useRef<Array<any | null>>([]);
  const bgColor = useThemeColor({}, "cardBg");

  const selectCategory = (index: number) => {
    const selected = itemsRef.current[index];
    setActiveIndex(index);
    selected?.measure((x: number) => {
      if (Platform.OS === "ios") {
        scrollRef.current?.scrollTo({ x: x, y: 0, animated: true });
      }
    });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    // onCategoryChanged(categories[index].name);
  };

  return (
    <SafeAreaView
      style={{
        flex: 1,
      }}
    >
      <ScrollView
        style={{
          flexGrow: 0,
          marginVertical: 24,
          flexShrink: 0,
        }}
        horizontal
        ref={scrollRef}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{
          alignItems: "flex-start",
          alignSelf: "flex-start",
          gap: 12,
        }}
      >
        {discoverData.map((item, index) => (
          <Button
            icon={item.icon}
            ref={(el) => (itemsRef.current[index] = el)}
            key={index}
            style={{
              borderRadius: 100,
              borderWidth: 1,
              marginLeft: index === 0 ? 12 : 0,
              marginRight: index === discoverData.length - 1 ? 12 : 0,
            }}
            labelStyle={{
              fontSize: 14,
              marginHorizontal: 20,
              marginVertical: 8,
            }}
            contentStyle={{ paddingVertical: 0 }}
            mode={activeIndex === index ? "contained" : "outlined"}
            onPress={() => selectCategory(index)}
          >
            {item.category}
          </Button>
        ))}
      </ScrollView>
      <ScrollView style={{ paddingHorizontal: 12 }}>
        <View style={{ gap: 16, paddingBottom: 20 }}>
          {discoverData[activeIndex].data.map((item, index) => (
            <TouchableOpacity key={index}>
              <Card mode="contained" style={{ backgroundColor: bgColor }}>
                <Card.Content>
                  <View style={{ flexDirection: "row", gap: 8 }}>
                    <View
                      style={{
                        height: 50,
                        width: 50,
                        borderRadius: 100,
                        backgroundColor:
                          pastelColors[index % pastelColors.length],
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    >
                      {item.icon}
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text numberOfLines={1} variant="titleLarge">
                        {item.title}
                      </Text>
                      <Text numberOfLines={2} variant="bodyMedium">
                        {item.subTitle}
                      </Text>
                    </View>
                  </View>
                </Card.Content>
              </Card>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
